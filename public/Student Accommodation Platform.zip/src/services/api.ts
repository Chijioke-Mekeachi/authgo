/**
 * API Client for DormDash Backend
 * Base URL: http://localhost:2100
 */

const API_BASE_URL = 'http://localhost:2100';

// Get auth token from localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('dormdash_token');
};

// Get refresh token from localStorage
const getRefreshToken = (): string | null => {
  return localStorage.getItem('dormdash_refresh_token');
};

// Set auth tokens
export const setAuthTokens = (token: string, refreshToken: string) => {
  localStorage.setItem('dormdash_token', token);
  localStorage.setItem('dormdash_refresh_token', refreshToken);
};

// Clear auth tokens
export const clearAuthTokens = () => {
  localStorage.removeItem('dormdash_token');
  localStorage.removeItem('dormdash_refresh_token');
  localStorage.removeItem('dormdash_user');
};

// API Error class
export class ApiError extends Error {
  constructor(public status: number, message: string, public data?: any) {
    super(message);
    this.name = 'ApiError';
  }
}

// Check if backend is available
let backendAvailable = true;

// Generic fetch wrapper with auth
async function fetchWithAuth(
  endpoint: string,
  options: RequestInit = {}
): Promise<any> {
  const token = getAuthToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });
  } catch (error) {
    // Network error - backend not available
    backendAvailable = false;
    throw new ApiError(
      0,
      '⚠️ Backend server is not running. Please ensure the backend is running on http://localhost:2100\n\nTo start the backend:\n1. Navigate to your backend directory\n2. Run: npm start or node server.js\n3. Verify it\'s running on port 2100',
      { originalError: error }
    );
  }

  // Handle 401 - Try to refresh token
  if (response.status === 401) {
    const refreshToken = getRefreshToken();
    if (refreshToken) {
      try {
        const refreshResponse = await fetch(`${API_BASE_URL}/auth/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken }),
        });

        if (refreshResponse.ok) {
          const { token: newToken, refreshToken: newRefreshToken } = await refreshResponse.json();
          setAuthTokens(newToken, newRefreshToken);
          
          // Retry original request with new token
          headers['Authorization'] = `Bearer ${newToken}`;
          const retryResponse = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers,
          });

          if (!retryResponse.ok) {
            throw new ApiError(retryResponse.status, 'Request failed after token refresh');
          }

          return retryResponse.json();
        }
      } catch (error) {
        // Refresh failed, clear tokens and redirect to login
        clearAuthTokens();
        window.location.href = '/';
        throw new ApiError(401, 'Session expired. Please login again.');
      }
    } else {
      clearAuthTokens();
      window.location.href = '/';
      throw new ApiError(401, 'Unauthorized. Please login.');
    }
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new ApiError(
      response.status,
      errorData.message || `HTTP Error ${response.status}`,
      errorData
    );
  }

  return response.json();
}

// Upload file wrapper
async function uploadFile(endpoint: string, formData: FormData): Promise<any> {
  const token = getAuthToken();
  
  const headers: HeadersInit = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'POST',
    headers,
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new ApiError(
      response.status,
      errorData.message || `Upload failed with status ${response.status}`,
      errorData
    );
  }

  return response.json();
}

// ==================== AUTHENTICATION ====================

export const authApi = {
  signup: async (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'landlord' | 'agent';
  }) => {
    return fetchWithAuth('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  login: async (data: { email: string; password: string }) => {
    return fetchWithAuth('/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  logout: async () => {
    return fetchWithAuth('/auth/logout', {
      method: 'POST',
    });
  },

  refreshToken: async (refreshToken: string) => {
    return fetchWithAuth('/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refreshToken }),
    });
  },
};

// ==================== PROFILE ====================

export const profileApi = {
  createProfile: async (data: any) => {
    return fetchWithAuth('/profile/createProfile', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getProfile: async () => {
    return fetchWithAuth('/profile/getProfile', {
      method: 'POST',
    });
  },

  updateProfile: async (data: any) => {
    return fetchWithAuth('/profile/updateProfile', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  getAnalysis: async () => {
    return fetchWithAuth('/profile/getAnalysis', {
      method: 'POST',
    });
  },

  updateListing: async (data: any) => {
    return fetchWithAuth('/profile/updateListing', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// ==================== PROPERTIES / PRODUCT ====================

export const productApi = {
  create: async (data: {
    title: string;
    description: string;
    price: number;
    location: string;
    type: string;
    bedrooms: number;
    bathrooms: number;
    amenities: string[];
  }) => {
    return fetchWithAuth('/product/create', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  uploadImages: async (productId: string, images: File[]) => {
    const formData = new FormData();
    images.forEach((image) => {
      formData.append('images', image);
    });
    return uploadFile(`/product/${productId}/images`, formData);
  },

  getAll: async () => {
    return fetch(`${API_BASE_URL}/product/all`).then((res) => res.json());
  },

  getByOwner: async (ownerEmail: string) => {
    return fetch(`${API_BASE_URL}/product/owner/${ownerEmail}`).then((res) =>
      res.json()
    );
  },

  delete: async (id: string) => {
    return fetchWithAuth(`/product/delete/${id}`, {
      method: 'DELETE',
    });
  },

  update: async (id: string, data: any) => {
    return fetchWithAuth(`/product/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  search: async (params: {
    location?: string;
    minPrice?: number;
    maxPrice?: number;
    type?: string;
    amenities?: string[];
  }) => {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          queryParams.append(key, value.join(','));
        } else {
          queryParams.append(key, String(value));
        }
      }
    });
    return fetch(`${API_BASE_URL}/product/search?${queryParams}`).then((res) =>
      res.json()
    );
  },
};

// ==================== INQUIRIES & MESSAGES ====================

export const inquiryApi = {
  create: async (data: {
    propertyId: string;
    message: string;
    name: string;
    email: string;
    phone: string;
  }) => {
    return fetchWithAuth('/inquiries', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getByProperty: async (propertyId: string) => {
    return fetchWithAuth(`/inquiries?propertyId=${propertyId}`);
  },
};

export const messageApi = {
  send: async (data: {
    receiverId: string;
    propertyId?: string;
    message: string;
  }) => {
    return fetchWithAuth('/messages/send', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getUserMessages: async (userId: string) => {
    return fetchWithAuth(`/messages/user/${userId}`);
  },
};

// ==================== FAVORITES ====================

export const favoriteApi = {
  add: async (data: { userId: string; propertyId: string }) => {
    return fetchWithAuth('/favorites', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getByUser: async (userId: string) => {
    return fetchWithAuth(`/favorites?userId=${userId}`);
  },

  remove: async (id: string) => {
    return fetchWithAuth(`/favorites/${id}`, {
      method: 'DELETE',
    });
  },
};

// ==================== PAYMENTS ====================

export const paymentApi = {
  getBoostPlans: async () => {
    return fetchWithAuth('/payments/boost/plans');
  },

  initiatePayment: async (data: {
    email: string;
    amount: number;
    propertyId: string;
    planId: string;
  }) => {
    return fetchWithAuth('/payments/paystack/initiate', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  verifyPayment: async (reference: string) => {
    return fetchWithAuth(`/payments/paystack/verify/${reference}`);
  },
};

// ==================== LANDLORD ====================

export const landlordApi = {
  getDashboard: async () => {
    return fetchWithAuth('/landlord/dashboard', {
      method: 'POST',
    });
  },

  getListings: async () => {
    return fetchWithAuth('/landlord/getListings', {
      method: 'POST',
    });
  },

  createListing: async (data: any) => {
    return fetchWithAuth('/landlord/createListing', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateListingStatus: async (data: { listingId: string; status: string }) => {
    return fetchWithAuth('/landlord/updateListingStatus', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },
};

// ==================== AGENT ====================

export const agentApi = {
  getCommissions: async (agentId: string) => {
    return fetchWithAuth(`/agent/${agentId}/commissions`);
  },

  settleCommission: async (data: { commissionId: string }) => {
    return fetchWithAuth('/agent/commissions/settle', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

// ==================== ADMIN ====================

export const adminApi = {
  getProperties: async () => {
    return fetchWithAuth('/admin/properties');
  },

  getStats: async () => {
    return fetchWithAuth('/admin/stats');
  },

  deleteProperty: async (id: string) => {
    return fetchWithAuth(`/admin/property/${id}`, {
      method: 'DELETE',
    });
  },
};

export default {
  auth: authApi,
  profile: profileApi,
  product: productApi,
  inquiry: inquiryApi,
  message: messageApi,
  favorite: favoriteApi,
  payment: paymentApi,
  landlord: landlordApi,
  agent: agentApi,
  admin: adminApi,
};
