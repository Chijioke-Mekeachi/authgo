# 🚀 DormDash Setup Guide

## Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- Backend server running on `http://localhost:2100`

---

## 🔧 Backend Setup

### Step 1: Start Your Backend Server

The DormDash frontend requires a backend API running on **port 2100**.

```bash
# Navigate to your backend directory
cd /path/to/dormdash-backend

# Install dependencies (if not already done)
npm install

# Start the backend server
npm start
# OR
node server.js
```

### Step 2: Verify Backend is Running

Open your browser and check:
- **URL:** `http://localhost:2100`
- **Expected Response:** Backend should return an API status or welcome message

### Step 3: Test API Endpoints

Test a few endpoints to ensure the backend is working:

```bash
# Health check (if available)
curl http://localhost:2100/health

# Or test the properties endpoint
curl http://localhost:2100/product/all
```

---

## 🎨 Frontend Setup

### Step 1: The Frontend is Already Running!

This environment automatically runs the frontend. You don't need to do anything.

### Step 2: Configure API Connection (Optional)

If your backend is running on a different port or host, update:

**File:** `/services/api.ts`

```typescript
const API_BASE_URL = 'http://localhost:2100'; // Change this if needed
```

---

## 🔍 Troubleshooting

### Error: "Failed to fetch" or "Backend server is not running"

**Cause:** The backend server at `http://localhost:2100` is not responding.

**Solutions:**

1. **Check if backend is running:**
   ```bash
   # Look for a process on port 2100
   lsof -i :2100  # macOS/Linux
   netstat -ano | findstr :2100  # Windows
   ```

2. **Start the backend:**
   ```bash
   cd /path/to/backend
   npm start
   ```

3. **Check the port:**
   - Ensure backend is configured to run on port 2100
   - Check backend `.env` or config files
   - Common port configurations:
     ```
     PORT=2100
     ```

4. **CORS Issues:**
   If you see CORS errors, ensure your backend has CORS enabled:
   
   ```javascript
   // In your backend (Express example)
   const cors = require('cors');
   app.use(cors({
     origin: 'http://localhost:5173', // or your frontend URL
     credentials: true
   }));
   ```

---

### Error: 401 Unauthorized

**Cause:** Invalid or expired authentication token.

**Solutions:**

1. **Clear localStorage:**
   ```javascript
   // In browser console
   localStorage.clear();
   ```

2. **Login again** with valid credentials

3. **Check token expiration** in backend settings

---

### Error: Properties not loading

**Cause:** Database is empty or endpoint is not working.

**Solutions:**

1. **Check backend logs** for errors

2. **Test the endpoint directly:**
   ```bash
   curl http://localhost:2100/product/all
   ```

3. **Add sample data** to your backend database

4. **Check backend routes** are properly configured

---

## 📋 Backend Requirements

Your backend must implement these endpoints:

### Authentication
- `POST /auth/signup` - User registration
- `POST /auth/login` - User login
- `POST /auth/logout` - User logout
- `POST /auth/refresh` - Token refresh

### Properties
- `POST /product/create` - Create property
- `POST /product/:id/images` - Upload images
- `GET /product/all` - Get all properties
- `GET /product/owner/:ownerEmail` - Get owner properties
- `DELETE /product/delete/:id` - Delete property
- `PUT /product/:id` - Update property
- `GET /product/search` - Search properties

### Profile
- `POST /profile/createProfile` - Create profile
- `POST /profile/getProfile` - Get profile
- `PUT /profile/updateProfile` - Update profile
- `POST /profile/getAnalysis` - Get analytics

### Landlord
- `POST /landlord/dashboard` - Dashboard data
- `POST /landlord/getListings` - Get listings
- `POST /landlord/createListing` - Create listing
- `PUT /landlord/updateListingStatus` - Update status

### Payments
- `GET /payments/boost/plans` - Get boost plans
- `POST /payments/paystack/initiate` - Initiate payment
- `GET /payments/paystack/verify/:reference` - Verify payment

### Others
- Inquiries, Messages, Favorites, Agent, Admin endpoints

**See `/BACKEND_INTEGRATION.md` for complete API documentation.**

---

## 🎯 Testing the Integration

### 1. Test Authentication

1. Go to the login/signup page
2. Create a new account as "Landlord" or "Agent"
3. Check browser console for any errors
4. Verify you're redirected to the dashboard

**Expected Result:**
- ✅ No "Failed to fetch" errors
- ✅ Token saved in localStorage
- ✅ User data displayed in dashboard

### 2. Test Property Creation

1. Navigate to Landlord Dashboard
2. Click "Add Property"
3. Fill in all required fields
4. Upload at least one image
5. Submit the form

**Expected Result:**
- ✅ Property created successfully
- ✅ Images uploaded
- ✅ Property appears in your listings
- ✅ Success toast notification

### 3. Test Property Search

1. Navigate to "Search Properties"
2. Use filters (location, price, type)
3. Search by keyword

**Expected Result:**
- ✅ Properties load from backend
- ✅ Filters work correctly
- ✅ Images display properly

---

## 🔐 Environment Variables

### Frontend (Optional)

Create a `.env` file if you need to configure:

```env
VITE_API_BASE_URL=http://localhost:2100
VITE_PAYSTACK_PUBLIC_KEY=pk_test_xxxxx
```

### Backend (Required)

Ensure your backend has:

```env
PORT=2100
DATABASE_URL=mongodb://localhost:27017/dormdash
JWT_SECRET=your-super-secret-key
PAYSTACK_SECRET_KEY=sk_test_xxxxx
```

---

## 📊 Backend Response Format

### Expected Response Structure

#### Login Response:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "123",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+234 800 000 0000",
    "role": "landlord",
    "verified": true,
    "createdAt": "2025-10-17T00:00:00.000Z"
  }
}
```

#### Properties Response:
```json
{
  "success": true,
  "properties": [
    {
      "id": "prop-123",
      "title": "Modern 2-Bedroom Apartment",
      "description": "Beautiful apartment near UNILAG",
      "price": 150000,
      "location": "Lagos State",
      "type": "apartment",
      "bedrooms": 2,
      "bathrooms": 2,
      "amenities": ["wifi", "parking", "security"],
      "images": ["https://...", "https://..."],
      "verified": true,
      "views": 45,
      "inquiries": 12,
      "landlord": {
        "name": "John Doe",
        "phone": "+234 800 000 0000",
        "verified": true
      }
    }
  ]
}
```

---

## 🚨 Common Issues

### Issue: CORS Policy Error

**Error Message:**
```
Access to fetch at 'http://localhost:2100/auth/login' from origin 'http://localhost:5173' 
has been blocked by CORS policy
```

**Fix:**
Add CORS middleware to your backend:

```javascript
// Express.js example
const cors = require('cors');

app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
```

---

### Issue: Database Connection Failed

**Error in Backend:**
```
MongoError: failed to connect to server
```

**Fix:**
1. Start MongoDB:
   ```bash
   mongod --dbpath /path/to/data
   ```

2. Check connection string in backend `.env`:
   ```env
   DATABASE_URL=mongodb://localhost:27017/dormdash
   ```

---

### Issue: Images Not Displaying

**Possible Causes:**
- Images not uploaded to backend
- Backend not serving static files
- Incorrect image URLs

**Fix:**
1. Check backend static file configuration:
   ```javascript
   app.use('/uploads', express.static('uploads'));
   ```

2. Verify image URLs in database

3. Check file upload middleware (multer, etc.)

---

## 📱 Testing Checklist

Before considering setup complete, test:

- [ ] Backend is running on port 2100
- [ ] Frontend can reach backend (no CORS errors)
- [ ] User can sign up as landlord
- [ ] User can sign up as agent
- [ ] User can login with email/password
- [ ] Token is saved in localStorage
- [ ] User can create a property
- [ ] Images upload successfully
- [ ] Properties appear in search
- [ ] Filters work correctly
- [ ] WhatsApp contact links work
- [ ] User can edit their profile
- [ ] Dashboard analytics display correctly

---

## 📞 Need Help?

### Check These First:

1. **Backend Logs:** Check console output for errors
2. **Frontend Console:** Open browser DevTools > Console
3. **Network Tab:** Check API requests and responses
4. **localStorage:** Verify tokens are being stored

### Debug Steps:

1. **Test backend directly:**
   ```bash
   curl -X POST http://localhost:2100/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","password":"password123"}'
   ```

2. **Check frontend requests:**
   - Open DevTools > Network tab
   - Try to login
   - Check if request is being sent
   - Check response status and body

3. **Verify API base URL:**
   - Check `/services/api.ts`
   - Ensure it matches backend URL

---

## ✅ Success Indicators

You'll know everything is working when:

1. ✅ No "Failed to fetch" errors
2. ✅ Login/Signup works smoothly
3. ✅ Dashboard loads with analytics
4. ✅ Properties can be created and edited
5. ✅ Images upload and display
6. ✅ Search and filters work
7. ✅ WhatsApp links open correctly
8. ✅ Toast notifications appear for actions

---

## 🎓 Next Steps

Once setup is complete:

1. **Add sample data** to test the full experience
2. **Configure Paystack** for payments
3. **Set up email service** for notifications
4. **Deploy to production** (see deployment guide)
5. **Configure domain** and SSL certificates

---

**Happy coding! 🚀**

For more detailed API documentation, see `/BACKEND_INTEGRATION.md`
