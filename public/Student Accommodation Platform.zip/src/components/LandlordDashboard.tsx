import React, { useState } from 'react';
import { Plus, Home, Eye, Edit, Trash2, MessageSquare, X, Upload, Check, Loader2, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { Skeleton } from './ui/skeleton';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { User as UserType } from '../types';
import { formatCurrency, createWhatsAppUrl } from '../utils/helpers';
import { LOCATIONS, PROPERTY_TYPES, AMENITIES } from '../data/constants';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';
import { useLandlordListings, useLandlordDashboard, useCreateListing, useUpdateProperty, useDeleteProperty, useUploadPropertyImages } from '../hooks/useApi';

interface LandlordDashboardProps {
  user: UserType;
}

interface PropertyFormData {
  title: string;
  description: string;
  price: string;
  location: string;
  type: string;
  bedrooms: string;
  bathrooms: string;
  amenities: string[];
}

const initialFormData: PropertyFormData = {
  title: '',
  description: '',
  price: '',
  location: '',
  type: '',
  bedrooms: '1',
  bathrooms: '1',
  amenities: []
};

export function LandlordDashboard({ user }: LandlordDashboardProps) {
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);
  const [isEditPropertyOpen, setIsEditPropertyOpen] = useState(false);
  const [propertyToDelete, setPropertyToDelete] = useState<string | null>(null);
  const [editingPropertyId, setEditingPropertyId] = useState<string | null>(null);
  const [formData, setFormData] = useState<PropertyFormData>(initialFormData);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  // API Hooks
  const { data: dashboardData, isLoading: isDashboardLoading } = useLandlordDashboard();
  const { data: listingsData, isLoading: isListingsLoading } = useLandlordListings();
  const createListing = useCreateListing();
  const updateProperty = useUpdateProperty();
  const deleteProperty = useDeleteProperty();
  const uploadImages = useUploadPropertyImages();

  const properties = listingsData?.listings || [];
  const analytics = dashboardData?.analytics || {
    activeListings: 0,
    totalViews: 0,
    totalInquiries: 0,
    pendingApproval: 0
  };

  const stats = [
    { 
      label: 'Active Listings', 
      value: analytics.activeListings?.toString() || '0', 
      icon: Home, 
      gradient: 'from-blue-500 to-blue-600'
    },
    { 
      label: 'Total Views', 
      value: analytics.totalViews?.toString() || '0', 
      icon: Eye, 
      gradient: 'from-purple-500 to-purple-600'
    },
    { 
      label: 'Inquiries', 
      value: analytics.totalInquiries?.toString() || '0', 
      icon: MessageSquare, 
      gradient: 'from-green-500 to-green-600'
    },
    { 
      label: 'Pending Approval', 
      value: analytics.pendingApproval?.toString() || '0', 
      icon: TrendingUp, 
      gradient: 'from-orange-500 to-orange-600'
    }
  ];

  const handleFormChange = (field: keyof PropertyFormData, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenity) 
        ? prev.filter(a => a !== amenity)
        : [...prev, amenity]
    );
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles = Array.from(files);
    
    if (imageFiles.length + newFiles.length > 10) {
      toast.error('Maximum 10 images allowed');
      return;
    }

    // Create previews
    const newPreviews: string[] = [];
    newFiles.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newPreviews.push(reader.result as string);
        if (newPreviews.length === newFiles.length) {
          setImagePreviews(prev => [...prev, ...newPreviews]);
        }
      };
      reader.readAsDataURL(file);
    });

    setImageFiles(prev => [...prev, ...newFiles]);
  };

  const removeImage = (index: number) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.title || !formData.description || !formData.price || !formData.location || !formData.type) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (imageFiles.length === 0 && !editingPropertyId) {
      toast.error('Please upload at least one image');
      return;
    }

    try {
      const propertyData = {
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        location: formData.location,
        type: formData.type,
        bedrooms: parseInt(formData.bedrooms),
        bathrooms: parseInt(formData.bathrooms),
        amenities: selectedAmenities,
      };

      if (editingPropertyId) {
        // Update existing property
        await updateProperty.mutateAsync({ id: editingPropertyId, data: propertyData });
        
        // Upload new images if any
        if (imageFiles.length > 0) {
          await uploadImages.mutateAsync({ productId: editingPropertyId, images: imageFiles });
        }
        
        setIsEditPropertyOpen(false);
      } else {
        // Create new property
        const response = await createListing.mutateAsync(propertyData);
        
        // Upload images
        if (response?.listing?.id && imageFiles.length > 0) {
          await uploadImages.mutateAsync({ productId: response.listing.id, images: imageFiles });
        }
        
        setIsAddPropertyOpen(false);
      }

      // Reset form
      setFormData(initialFormData);
      setSelectedAmenities([]);
      setImageFiles([]);
      setImagePreviews([]);
      setEditingPropertyId(null);
    } catch (error: any) {
      console.error('Failed to save property:', error);
    }
  };

  const handleEdit = (property: any) => {
    setEditingPropertyId(property.id || property._id);
    setFormData({
      title: property.title,
      description: property.description,
      price: property.price.toString(),
      location: property.location,
      type: property.type,
      bedrooms: property.bedrooms.toString(),
      bathrooms: property.bathrooms.toString(),
      amenities: property.amenities
    });
    setSelectedAmenities(property.amenities || []);
    setIsEditPropertyOpen(true);
  };

  const handleDelete = async () => {
    if (!propertyToDelete) return;

    try {
      await deleteProperty.mutateAsync(propertyToDelete);
      setPropertyToDelete(null);
    } catch (error: any) {
      console.error('Failed to delete property:', error);
    }
  };

  const PropertyForm = () => (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Property Title */}
      <div>
        <Label htmlFor="title">Property Title *</Label>
        <Input
          id="title"
          placeholder="e.g., Modern 2-Bedroom Apartment Near UNILAG"
          value={formData.title}
          onChange={(e) => handleFormChange('title', e.target.value)}
          required
          className="mt-1"
        />
      </div>

      {/* Description */}
      <div>
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Describe your property, its features, and what makes it special..."
          value={formData.description}
          onChange={(e) => handleFormChange('description', e.target.value)}
          required
          rows={4}
          className="mt-1"
        />
      </div>

      {/* Price, Location, Type */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="price">Annual Rent (₦) *</Label>
          <Input
            id="price"
            type="number"
            placeholder="e.g., 150000"
            value={formData.price}
            onChange={(e) => handleFormChange('price', e.target.value)}
            required
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="location">Location *</Label>
          <Select value={formData.location} onValueChange={(value) => handleFormChange('location', value)}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              {LOCATIONS.map((location) => (
                <SelectItem key={location} value={location}>
                  {location}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="type">Property Type *</Label>
          <Select value={formData.type} onValueChange={(value) => handleFormChange('type', value)}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              {PROPERTY_TYPES.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Bedrooms and Bathrooms */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="bedrooms">Bedrooms</Label>
          <Select value={formData.bedrooms} onValueChange={(value) => handleFormChange('bedrooms', value)}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 4, 5].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} Bedroom{num > 1 ? 's' : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="bathrooms">Bathrooms</Label>
          <Select value={formData.bathrooms} onValueChange={(value) => handleFormChange('bathrooms', value)}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 4].map((num) => (
                <SelectItem key={num} value={num.toString()}>
                  {num} Bathroom{num > 1 ? 's' : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Amenities */}
      <div>
        <Label>Amenities</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
          {AMENITIES.map((amenity) => (
            <button
              key={amenity}
              type="button"
              onClick={() => handleAmenityToggle(amenity)}
              className={`px-3 py-2 rounded-lg text-sm border transition-all ${
                selectedAmenities.includes(amenity)
                  ? 'bg-blue-50 border-blue-500 text-blue-700'
                  : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
              }`}
            >
              {selectedAmenities.includes(amenity) && <Check className="inline h-3 w-3 mr-1" />}
              {amenity.charAt(0).toUpperCase() + amenity.slice(1).replace('-', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Image Upload */}
      <div>
        <Label>Property Images * (Max 10 images)</Label>
        <div className="mt-2 space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageSelect}
              className="hidden"
              id="image-upload"
              disabled={imageFiles.length >= 10}
            />
            <label htmlFor="image-upload" className="cursor-pointer">
              <div className="flex flex-col items-center">
                <Upload className="h-12 w-12 text-gray-400 mb-3" />
                <p className="text-sm text-gray-600 mb-1">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-gray-500">
                  PNG, JPG up to 5MB ({imageFiles.length}/10)
                </p>
              </div>
            </label>
          </div>

          {/* Image Previews */}
          {imagePreviews.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <AnimatePresence>
                {imagePreviews.map((preview, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="relative group aspect-square rounded-lg overflow-hidden border-2 border-gray-200"
                  >
                    <img
                      src={preview}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end space-x-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setIsAddPropertyOpen(false);
            setIsEditPropertyOpen(false);
            setFormData(initialFormData);
            setSelectedAmenities([]);
            setImageFiles([]);
            setImagePreviews([]);
            setEditingPropertyId(null);
          }}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700"
          disabled={createListing.isPending || updateProperty.isPending || uploadImages.isPending}
        >
          {createListing.isPending || updateProperty.isPending || uploadImages.isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : editingPropertyId ? (
            'Update Property'
          ) : (
            'Add Property'
          )}
        </Button>
      </div>
    </form>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl text-gray-900 mb-2">Landlord Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user.name}! Manage your properties and track performance.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className={`bg-gradient-to-r ${stat.gradient} p-4 text-white`}>
                    <stat.icon className="h-8 w-8 mb-2" />
                    <p className="text-3xl mb-1">{stat.value}</p>
                    <p className="text-sm opacity-90">{stat.label}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Add Property Button */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl text-gray-900">Your Properties</h2>
          <Button
            onClick={() => setIsAddPropertyOpen(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Property
          </Button>
        </div>

        {/* Properties List */}
        {isListingsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-48 w-full mb-4 rounded-lg" />
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : properties.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Home className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl text-gray-900 mb-2">No Properties Yet</h3>
              <p className="text-gray-600 mb-6">
                Start by adding your first property to DormDash
              </p>
              <Button
                onClick={() => setIsAddPropertyOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Property
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {properties.map((property: any, index: number) => (
                <motion.div
                  key={property.id || property._id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <ImageWithFallback
                        src={property.images?.[0] || 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800'}
                        alt={property.title}
                        className="w-full h-48 object-cover"
                      />
                      <Badge
                        className={`absolute top-3 right-3 ${
                          property.verified || property.status === 'active'
                            ? 'bg-green-500'
                            : 'bg-orange-500'
                        }`}
                      >
                        {property.verified || property.status === 'active' ? 'Active' : 'Pending'}
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="text-lg text-gray-900 mb-2 line-clamp-1">
                        {property.title}
                      </h3>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                        {property.description}
                      </p>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-xl text-blue-600">
                          {formatCurrency(property.price)}/year
                        </span>
                        <span className="text-sm text-gray-500">
                          {property.location}
                        </span>
                      </div>

                      {/* Analytics */}
                      <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-gray-50 rounded-lg">
                        <div className="text-center">
                          <Eye className="h-4 w-4 text-gray-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-900">{property.views || 0}</p>
                          <p className="text-xs text-gray-500">Views</p>
                        </div>
                        <div className="text-center">
                          <MessageSquare className="h-4 w-4 text-gray-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-900">{property.inquiries || 0}</p>
                          <p className="text-xs text-gray-500">Inquiries</p>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(property)}
                          className="flex-1"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setPropertyToDelete(property.id || property._id)}
                          className="flex-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Add Property Dialog */}
      <Dialog open={isAddPropertyOpen} onOpenChange={setIsAddPropertyOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Property</DialogTitle>
            <DialogDescription>
              Fill in the details to list your property on DormDash
            </DialogDescription>
          </DialogHeader>
          <PropertyForm />
        </DialogContent>
      </Dialog>

      {/* Edit Property Dialog */}
      <Dialog open={isEditPropertyOpen} onOpenChange={setIsEditPropertyOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Property</DialogTitle>
            <DialogDescription>
              Update your property information
            </DialogDescription>
          </DialogHeader>
          <PropertyForm />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!propertyToDelete} onOpenChange={() => setPropertyToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Property</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this property? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
