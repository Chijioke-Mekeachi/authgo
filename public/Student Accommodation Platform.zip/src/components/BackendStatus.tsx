import React, { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, Wifi, WifiOff } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';

const API_BASE_URL = 'http://localhost:2100';

export function BackendStatus() {
  const [isOnline, setIsOnline] = useState<boolean | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const checkBackendStatus = async () => {
    setIsChecking(true);
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);

      const response = await fetch(`${API_BASE_URL}/health`, {
        method: 'GET',
        signal: controller.signal,
      }).catch(() => {
        // If /health doesn't exist, try the base URL
        return fetch(API_BASE_URL, {
          method: 'GET',
          signal: controller.signal,
        });
      });

      clearTimeout(timeoutId);
      setIsOnline(response.ok || response.status === 404); // 404 means server is running but no route
    } catch (error) {
      setIsOnline(false);
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    checkBackendStatus();
    
    // Check every 30 seconds
    const interval = setInterval(checkBackendStatus, 30000);
    
    return () => clearInterval(interval);
  }, []);

  // Don't show anything if we haven't checked yet
  if (isOnline === null) {
    return null;
  }

  // Only show warning if offline
  if (!isOnline) {
    return (
      <div className="bg-red-50 border-b border-red-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Alert className="border-red-300 bg-red-50">
            <WifiOff className="h-4 w-4 text-red-600" />
            <AlertDescription className="ml-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-red-800 font-semibold">Backend server is offline.</span>
                  <span className="text-red-700 text-sm ml-2">
                    Please start the backend on port 2100.
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowDetails(!showDetails)}
                    className="text-red-700 border-red-300 hover:bg-red-100"
                  >
                    {showDetails ? 'Hide' : 'Show'} Details
                  </Button>
                  <Button
                    size="sm"
                    onClick={checkBackendStatus}
                    disabled={isChecking}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    {isChecking ? 'Checking...' : 'Retry'}
                  </Button>
                </div>
              </div>
              
              {showDetails && (
                <div className="mt-3 p-3 bg-red-100 rounded-md text-sm text-red-800">
                  <p className="font-semibold mb-2">To fix this issue:</p>
                  <ol className="list-decimal list-inside space-y-1 ml-2">
                    <li>Navigate to your backend directory</li>
                    <li>Run: <code className="bg-red-200 px-1 rounded">npm start</code> or <code className="bg-red-200 px-1 rounded">node server.js</code></li>
                    <li>Ensure the server is running on <code className="bg-red-200 px-1 rounded">http://localhost:2100</code></li>
                    <li>Click "Retry" above to check connection</li>
                  </ol>
                  <p className="mt-2 text-xs">
                    See <code className="bg-red-200 px-1 rounded">/SETUP_GUIDE.md</code> for detailed setup instructions.
                  </p>
                </div>
              )}
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  // Optionally show success indicator (can be removed for cleaner UI)
  return null;
}
