/**
 * Application-wide constants
 */

export const APP_NAME = 'DormDash';

export const LOCATIONS = [
  'Lagos State',
  'Oyo State', 
  'Ogun State',
  'Federal Capital Territory',
  'Rivers State',
  'Enugu State',
  'Kaduna State',
  'Kano State'
];

export const PROPERTY_TYPES = [
  'Apartment',
  'House',
  'Hostel',
  'Single Room',
  'Self-Contained',
  'Studio'
];

export const AMENITIES = [
  'wifi',
  'electricity',
  'water',
  'parking',
  'security',
  'generator',
  'kitchen',
  'laundry',
  'furnished',
  'air-conditioning'
];

export const USER_ROLES = {
  STUDENT: 'student',
  LANDLORD: 'landlord',
  AGENT: 'agent',
  ADMIN: 'admin'
} as const;

export const BOOSTING_TIERS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 1500,
    duration: '7 days',
    features: [
      'Highlighted in search results',
      'Basic analytics',
      'Email support'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 3000,
    duration: '14 days',
    features: [
      'Top placement in search',
      'Advanced analytics',
      'Priority support',
      'Featured badge'
    ],
    popular: true
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 5000,
    duration: '30 days',
    features: [
      'Premium placement',
      'Comprehensive analytics',
      '24/7 support',
      'Verified badge',
      'Social media promotion'
    ]
  }
];

export const PRICE_RANGES = {
  MIN: 0,
  MAX: 500000,
  STEP: 10000
};

export const COMMISSION_RATES = {
  MIN: 5,
  MAX: 10,
  DEFAULT: 7.5
};
