import { NavigationItem } from '../types';

export const navigationItems: NavigationItem[] = [
  {
    id: 'home',
    name: 'Home',
    path: '/'
  },
  {
    id: 'search',
    name: 'Search Properties',
    path: '/search'
  },
  {
    id: 'boosting',
    name: 'Boosting Services',
    path: '/boosting'
  }
];
