import { User } from '../types';

export const mockUsers: Record<string, User> = {
  student: {
    id: 's1',
    name: 'Chioma Adeleke',
    email: 'chioma.adeleke@student.edu.ng',
    phone: '+2348012345678',
    role: 'student',
    verified: true,
    registrationDate: '2025-01-15'
  },
  landlord: {
    id: 'l1',
    name: 'Mr. Adebayo Johnson',
    email: 'adebayo.j@email.com',
    phone: '+2348012345678',
    role: 'landlord',
    verified: true,
    registrationDate: '2024-06-20'
  },
  agent: {
    id: 'a1',
    name: 'Emmanuel Okafor',
    email: 'emmanuel.agent@email.com',
    phone: '+2348123456789',
    role: 'agent',
    verified: true,
    registrationDate: '2024-08-10'
  },
  admin: {
    id: 'admin1',
    name: 'Admin User',
    email: 'admin@dormdash.ng',
    phone: '+2348000000000',
    role: 'admin',
    verified: true,
    registrationDate: '2024-01-01'
  }
};

export const defaultUser: User = mockUsers.student;
