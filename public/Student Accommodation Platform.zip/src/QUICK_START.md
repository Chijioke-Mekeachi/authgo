# ⚡ Quick Start Guide

## 🚨 Backend Not Running?

If you see "Failed to fetch" or "Backend server is not running" errors, follow these steps:

### Step 1: Locate Your Backend
```bash
cd /path/to/your/dormdash-backend
```

### Step 2: Start the Backend
```bash
npm start
# OR
node server.js
# OR
npm run dev
```

### Step 3: Verify It's Running
- The backend should start on **port 2100**
- You should see console output like: `Server running on port 2100`
- Test it: Open `http://localhost:2100` in your browser

### Step 4: Refresh the Frontend
- Once backend is running, refresh this page
- The error should disappear
- Try logging in or signing up

---

## 📋 Backend Checklist

Make sure your backend has:

- ✅ Running on port 2100
- ✅ CORS enabled for `http://localhost:5173`
- ✅ Database connected (MongoDB, PostgreSQL, etc.)
- ✅ All required endpoints implemented
- ✅ JWT authentication configured

---

## 🔧 Common Backend Port Issues

### If Port 2100 is Already in Use:

1. **Find what's using port 2100:**
   ```bash
   # macOS/Linux
   lsof -i :2100
   
   # Windows
   netstat -ano | findstr :2100
   ```

2. **Kill the process or change the port:**
   ```bash
   # Kill the process (use PID from above)
   kill -9 <PID>
   ```

3. **Or change the backend port:**
   - Update backend `.env` or config file
   - Then update frontend `/services/api.ts`:
     ```typescript
     const API_BASE_URL = 'http://localhost:YOUR_NEW_PORT';
     ```

---

## 🎯 Test Backend Endpoints

Use these commands to test if your backend is working:

```bash
# Test health/status
curl http://localhost:2100/health

# Test login
curl -X POST http://localhost:2100/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'

# Test get all properties
curl http://localhost:2100/product/all
```

---

## 📞 Still Having Issues?

1. **Check backend logs** - Look for error messages in the console
2. **Check database connection** - Ensure MongoDB/PostgreSQL is running
3. **Check .env file** - Verify all environment variables are set
4. **Check package.json** - Ensure all dependencies are installed

---

## ✅ Success Indicators

You'll know it's working when:
- ✅ No red error banner at the top
- ✅ Login/signup forms work
- ✅ Dashboard loads
- ✅ Properties display

---

**Need more help?** See `/SETUP_GUIDE.md` for detailed instructions.
