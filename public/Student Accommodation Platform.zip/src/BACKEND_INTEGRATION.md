# DormDash Backend Integration Guide

## 🎯 Overview

This document outlines how the DormDash frontend is connected to the backend API at `http://localhost:2100`.

---

## ✅ Completed Integrations

### 1. **Authentication System** ✓

#### Files Updated:
- `/services/api.ts` - API client with token management
- `/hooks/useAuth.ts` - Auth context and hooks
- `/hooks/useApi.ts` - React Query hooks for all endpoints
- `/components/AuthPage.tsx` - Login/Signup forms
- `/App.tsx` - Auth provider integration

#### Features:
- ✅ JWT token authentication
- ✅ Automatic token refresh on 401
- ✅ Remember me functionality
- ✅ Secure localStorage management
- ✅ Role-based access control (Landlord, Agent, Admin)

#### Endpoints Connected:
```typescript
POST /auth/signup        → Sign up new landlord/agent
POST /auth/login         → Login with email/password
POST /auth/logout        → Logout and clear session
POST /auth/refresh       → Refresh expired tokens
```

#### Usage Example:
```typescript
import { useAuth } from './hooks/useAuth';

const { user, login, logout, signup } = useAuth();

// Login
await login('email@example.com', 'password', true); // remember me

// Signup
await signup({
  name: 'John Doe',
  email: 'john@example.com',
  password: 'secure123',
  phone: '+234 800 000 0000',
  role: 'landlord'
});
```

---

### 2. **Property Management** ✓

#### Files Updated:
- `/components/LandlordDashboard.tsx` - Full backend integration
- `/components/PropertySearch.tsx` - Fetch and search properties
- `/hooks/useApi.ts` - Property hooks

#### Features:
- ✅ Create property with form data
- ✅ Upload multiple images (up to 10)
- ✅ Update existing properties
- ✅ Delete properties
- ✅ Fetch owner's properties
- ✅ Search properties with filters
- ✅ Real-time analytics (views, inquiries)

#### Endpoints Connected:
```typescript
POST   /product/create              → Create new property
POST   /product/:id/images          → Upload property images
GET    /product/all                 → Get all public properties
GET    /product/owner/:ownerEmail   → Get landlord's properties
DELETE /product/delete/:id          → Delete property
PUT    /product/:id                 → Update property
GET    /product/search?params       → Search with filters
```

#### Usage Example:
```typescript
import { useCreateProperty, useUploadPropertyImages, useOwnerProperties } from './hooks/useApi';

// Create property
const createProperty = useCreateProperty();
await createProperty.mutateAsync({
  title: 'Modern Apartment',
  description: 'Beautiful 2-bedroom apartment',
  price: 150000,
  location: 'Lagos State',
  type: 'Apartment',
  bedrooms: 2,
  bathrooms: 2,
  amenities: ['wifi', 'parking', 'security']
});

// Upload images
const uploadImages = useUploadPropertyImages();
await uploadImages.mutateAsync({
  productId: 'property-id',
  images: [file1, file2, file3]
});

// Fetch owner's properties
const { data } = useOwnerProperties('owner@email.com');
```

---

### 3. **Profile Management** ✓

#### Endpoints Connected:
```typescript
POST /profile/createProfile    → Create user profile
POST /profile/getProfile        → Fetch user profile
PUT  /profile/updateProfile     → Update profile info
POST /profile/getAnalysis       → Get analytics data
POST /profile/updateListing     → Update listing stats
```

#### Usage Example:
```typescript
import { useProfile, useUpdateProfile } from './hooks/useApi';

// Fetch profile
const { data: profile } = useProfile();

// Update profile
const updateProfile = useUpdateProfile();
await updateProfile.mutateAsync({
  name: 'New Name',
  phone: '+234 800 000 0000',
  avatar: 'https://...'
});
```

---

### 4. **Landlord Dashboard** ✓

#### Endpoints Connected:
```typescript
POST /landlord/dashboard           → Get dashboard analytics
POST /landlord/getListings         → Fetch all listings
POST /landlord/createListing       → Create new listing
PUT  /landlord/updateListingStatus → Update status
```

#### Features:
- ✅ Real-time analytics (active listings, views, inquiries)
- ✅ Property CRUD operations
- ✅ Image upload with progress
- ✅ Loading states and error handling
- ✅ Automatic cache invalidation

#### Usage Example:
```typescript
import { useLandlordDashboard, useLandlordListings } from './hooks/useApi';

// Dashboard analytics
const { data: dashboardData } = useLandlordDashboard();
const analytics = dashboardData?.analytics || {
  activeListings: 0,
  totalViews: 0,
  totalInquiries: 0,
  pendingApproval: 0
};

// Fetch listings
const { data: listingsData } = useLandlordListings();
const properties = listingsData?.listings || [];
```

---

### 5. **Agent Dashboard** 

#### Endpoints Connected:
```typescript
GET  /agent/:id/commissions      → Get commission history
POST /agent/commissions/settle   → Settle commission
```

#### Usage Example:
```typescript
import { useAgentCommissions, useSettleCommission } from './hooks/useApi';

const { data: commissions } = useAgentCommissions('agent-id');
const settleCommission = useSettleCommission();
```

---

### 6. **Admin Dashboard** 

#### Endpoints Connected:
```typescript
GET    /admin/properties       → Get all properties
GET    /admin/stats            → Get platform stats
DELETE /admin/property/:id     → Delete any property
```

#### Usage Example:
```typescript
import { useAdminProperties, useAdminStats } from './hooks/useApi';

const { data: properties } = useAdminProperties();
const { data: stats } = useAdminStats();
```

---

### 7. **Inquiries & Messages** 

#### Endpoints Connected:
```typescript
POST /inquiries                  → Send property inquiry
GET  /inquiries?propertyId=...   → Get property inquiries
POST /messages/send              → Send direct message
GET  /messages/user/:userId      → Get user messages
```

#### Usage Example:
```typescript
import { useCreateInquiry, useSendMessage, useUserMessages } from './hooks/useApi';

// Send inquiry
const createInquiry = useCreateInquiry();
await createInquiry.mutateAsync({
  propertyId: 'prop-123',
  message: 'I am interested in this property',
  name: 'John Doe',
  email: 'john@example.com',
  phone: '+234 800 000 0000'
});

// Fetch messages
const { data: messages } = useUserMessages('user-id');
```

---

### 8. **Favorites System** 

#### Endpoints Connected:
```typescript
POST   /favorites               → Add to favorites
GET    /favorites?userId=...    → Get user favorites
DELETE /favorites/:id           → Remove favorite
```

#### Usage Example:
```typescript
import { useAddFavorite, useRemoveFavorite, useFavorites } from './hooks/useApi';

const addFavorite = useAddFavorite();
await addFavorite.mutateAsync({
  userId: 'user-id',
  propertyId: 'prop-id'
});
```

---

### 9. **Payment Integration (Paystack)** 

#### Endpoints Connected:
```typescript
GET  /payments/boost/plans              → Get boost plans
POST /payments/paystack/initiate        → Start payment
GET  /payments/paystack/verify/:ref     → Verify payment
```

#### Features:
- ✅ Three boost tiers: Basic (₦1,500), Pro (₦3,000), Premium (₦5,000)
- ✅ Automatic redirect to Paystack
- ✅ Payment verification on callback
- ✅ Property boost activation

#### Usage Example:
```typescript
import { useBoostPlans, useInitiatePayment, useVerifyPayment } from './hooks/useApi';

// Get plans
const { data: plans } = useBoostPlans();

// Initiate payment
const initiatePayment = useInitiatePayment();
const response = await initiatePayment.mutateAsync({
  email: 'landlord@example.com',
  amount: 3000,
  propertyId: 'prop-id',
  planId: 'pro'
});
// User is automatically redirected to Paystack

// Verify payment (on callback)
const { data: verification } = useVerifyPayment('payment-reference');
```

---

## 🔧 Technical Implementation

### API Client (`/services/api.ts`)

#### Features:
- ✅ Centralized fetch wrapper
- ✅ Automatic token injection
- ✅ Token refresh on 401
- ✅ Error handling with custom ApiError class
- ✅ FormData support for file uploads
- ✅ TypeScript types for all endpoints

#### Configuration:
```typescript
const API_BASE_URL = 'http://localhost:2100';

// Token storage
localStorage.setItem('dormdash_token', token);
localStorage.setItem('dormdash_refresh_token', refreshToken);
```

---

### React Query Integration (`/hooks/useApi.ts`)

#### Features:
- ✅ Automatic caching (5-10 minute stale times)
- ✅ Optimistic updates
- ✅ Automatic refetching
- ✅ Cache invalidation on mutations
- ✅ Loading and error states
- ✅ Toast notifications

#### Query Configuration:
```typescript
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});
```

---

### Auth Provider (`/hooks/useAuth.ts`)

#### Features:
- ✅ React Context for global auth state
- ✅ Persistent login (localStorage)
- ✅ Remember me functionality
- ✅ Automatic token management
- ✅ Role-based access control hooks
- ✅ Protected route HOC

#### Context Usage:
```typescript
const { user, isAuthenticated, isLoading, login, logout, signup } = useAuth();

// Check authentication
if (!isAuthenticated) {
  redirect('/login');
}

// Role-based access
const { user } = useRequireRole(['landlord', 'admin']);
```

---

## 📊 Data Flow

### 1. **Login Flow:**
```
User enters credentials
    ↓
AuthPage calls useAuth().login()
    ↓
POST /auth/login
    ↓
Receive {token, refreshToken, user}
    ↓
Store tokens in localStorage
    ↓
Set user in AuthContext
    ↓
Redirect to dashboard
```

### 2. **Create Property Flow:**
```
User fills form + uploads images
    ↓
LandlordDashboard calls useCreateProperty()
    ↓
POST /product/create (property data)
    ↓
Receive {listing: {id, ...}}
    ↓
POST /product/:id/images (FormData)
    ↓
React Query invalidates ['properties']
    ↓
UI updates automatically
```

### 3. **Token Refresh Flow:**
```
API request returns 401
    ↓
fetchWithAuth detects 401
    ↓
POST /auth/refresh {refreshToken}
    ↓
Receive new {token, refreshToken}
    ↓
Store new tokens
    ↓
Retry original request
    ↓
Return response
```

---

## 🎨 UI/UX Features

### Loading States
- ✅ Skeleton screens while fetching
- ✅ Spinner animations during mutations
- ✅ Disabled buttons during API calls
- ✅ Progress indicators for uploads

### Error Handling
- ✅ Toast notifications for all errors
- ✅ Specific error messages from backend
- ✅ Fallback to generic messages
- ✅ Automatic retry on network errors

### Success Feedback
- ✅ Success toasts for all mutations
- ✅ Optimistic UI updates
- ✅ Smooth animations on data changes
- ✅ Confirmation dialogs for destructive actions

---

## 🔐 Security Features

### Authentication
- ✅ JWT tokens with expiration
- ✅ Refresh token rotation
- ✅ Automatic logout on token expiry
- ✅ HTTPS recommended for production

### API Security
- ✅ Authorization header on all protected routes
- ✅ Token validation on backend
- ✅ Role-based access control
- ✅ XSS protection (React escaping)

### Data Security
- ✅ No PII stored in localStorage
- ✅ Secure token management
- ✅ Input validation on all forms
- ✅ CSRF protection ready

---

## 🚀 Performance Optimizations

### Caching Strategy
```typescript
// Properties: 2 min stale time
{ staleTime: 2 * 60 * 1000 }

// Profile: 5 min stale time
{ staleTime: 5 * 60 * 1000 }

// Analytics: 10 min stale time
{ staleTime: 10 * 60 * 1000 }

// Messages: Auto-refetch every 30s
{ refetchInterval: 30000 }
```

### Image Optimization
- ✅ Lazy loading for property images
- ✅ Compressed uploads (max 5MB)
- ✅ Progressive image loading
- ✅ Fallback images

### Code Splitting
- ✅ Lazy-loaded components
- ✅ Dynamic imports for heavy pages
- ✅ Optimized bundle size
- ✅ Tree-shaking enabled

---

## 🧪 Testing Checklist

### Authentication
- [ ] Login with valid credentials
- [ ] Login with invalid credentials
- [ ] Signup as landlord
- [ ] Signup as agent
- [ ] Remember me checkbox
- [ ] Forgot password flow
- [ ] Token refresh on 401
- [ ] Logout clears tokens

### Properties
- [ ] Create property
- [ ] Upload images
- [ ] Edit property
- [ ] Delete property
- [ ] Search properties
- [ ] Filter by location
- [ ] Filter by price range
- [ ] Filter by amenities
- [ ] View property details

### Dashboard
- [ ] Load dashboard analytics
- [ ] Display active listings
- [ ] Show views/inquiries count
- [ ] Add new property
- [ ] Edit existing property
- [ ] Delete property with confirmation

### WhatsApp Integration
- [ ] Contact landlord button
- [ ] Pre-filled message
- [ ] Correct phone number
- [ ] Opens in new tab

---

## 📝 Environment Variables

### Required for Production:
```env
VITE_API_BASE_URL=https://api.dormdash.com
VITE_PAYSTACK_PUBLIC_KEY=pk_live_...
VITE_WHATSAPP_BUSINESS_NUMBER=+234...
```

---

## 🐛 Common Issues & Solutions

### Issue: 401 Unauthorized
**Solution:** Check if token is expired. Clear localStorage and login again.

### Issue: CORS Error
**Solution:** Ensure backend has CORS enabled for frontend origin.

### Issue: Images not uploading
**Solution:** Check file size (max 5MB) and format (JPG, PNG).

### Issue: Properties not showing
**Solution:** Check network tab for API response. Verify backend is running on port 2100.

---

## 📚 Next Steps

### Recommended Enhancements:
1. Add real-time notifications (WebSocket)
2. Implement in-app messaging
3. Add property comparison feature
4. Create agent commission tracking
5. Build admin moderation tools
6. Add property verification workflow
7. Implement advanced analytics
8. Create mobile app version

---

## 📞 Support

For backend API issues, contact the backend team.
For frontend integration issues, check:
- Browser console for errors
- Network tab for API calls
- React DevTools for state
- localStorage for tokens

---

**Last Updated:** October 2025  
**Backend API Version:** 1.0.0  
**Frontend Version:** 2.0.0
