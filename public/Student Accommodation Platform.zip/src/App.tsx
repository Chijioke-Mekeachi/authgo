import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { HomePage } from './components/home/HomePage';
import { PropertySearch } from './components/PropertySearch';
import { PropertyDetail } from './components/PropertyDetail';
import { LandlordDashboard } from './components/LandlordDashboard';
import { AgentDashboard } from './components/AgentDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthPage } from './components/AuthPage';
import { BoostingServices } from './components/BoostingServices';
import { ProfilePage } from './components/ProfilePage';
import { BackendStatus } from './components/BackendStatus';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { PageType, Property } from './types';
import { Toaster } from './components/ui/sonner';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

function AppContent() {
  const { user, isAuthenticated, logout: authLogout } = useAuth();
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  const handlePropertySelect = (property: Property) => {
    setSelectedProperty(property);
    setCurrentPage('property-detail');
  };

  const handleLogout = async () => {
    await authLogout();
    setCurrentPage('home');
  };

  const handleAuth = () => {
    // Navigate to appropriate dashboard based on role
    if (user?.role === 'landlord') {
      setCurrentPage('landlord-dashboard');
    } else if (user?.role === 'agent') {
      setCurrentPage('agent-dashboard');
    } else if (user?.role === 'admin') {
      setCurrentPage('admin-dashboard');
    } else {
      setCurrentPage('home');
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPropertySelect={handlePropertySelect} onNavigate={setCurrentPage} />;
      case 'search':
        return <PropertySearch onPropertySelect={handlePropertySelect} />;
      case 'property-detail':
        return selectedProperty ? (
          <PropertyDetail property={selectedProperty} onBack={() => setCurrentPage('search')} />
        ) : (
          <HomePage onPropertySelect={handlePropertySelect} onNavigate={setCurrentPage} />
        );
      case 'landlord-dashboard':
        return isAuthenticated && user ? <LandlordDashboard user={user} /> : <AuthPage onAuth={handleAuth} />;
      case 'agent-dashboard':
        return isAuthenticated && user ? <AgentDashboard user={user} /> : <AuthPage onAuth={handleAuth} />;
      case 'admin-dashboard':
        return isAuthenticated && user ? <AdminDashboard /> : <AuthPage onAuth={handleAuth} />;
      case 'auth':
        return <AuthPage onAuth={handleAuth} />;
      case 'boosting':
        return <BoostingServices />;
      case 'profile':
        return isAuthenticated && user ? (
          <ProfilePage user={user} onNavigate={setCurrentPage} />
        ) : (
          <AuthPage onAuth={handleAuth} />
        );
      default:
        return <HomePage onPropertySelect={handlePropertySelect} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" richColors />
      <BackendStatus />
      <Header
        currentPage={currentPage}
        user={user}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
      />
      
      <main>
        {renderPage()}
      </main>

      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
