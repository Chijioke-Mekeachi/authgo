import { useState, useEffect, useCallback } from 'react';
import { User } from '../types';

const USER_STORAGE_KEY = 'dormdash_user';
const REMEMBER_ME_KEY = 'dormdash_remember_me';

export const useAuthPersistence = () => {
  const [user, setUser] = useState<User | null>(null);
  const [rememberMe, setRememberMe] = useState(false);

  // Load user from storage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem(USER_STORAGE_KEY);
    const shouldRemember = localStorage.getItem(REMEMBER_ME_KEY) === 'true';
    
    if (storedUser && shouldRemember) {
      try {
        setUser(JSON.parse(storedUser));
        setRememberMe(true);
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem(USER_STORAGE_KEY);
      }
    }
  }, []);

  const login = useCallback((userData: User, remember: boolean = false) => {
    setUser(userData);
    setRememberMe(remember);
    
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userData));
    localStorage.setItem(REMEMBER_ME_KEY, remember.toString());
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setRememberMe(false);
    localStorage.removeItem(USER_STORAGE_KEY);
    localStorage.removeItem(REMEMBER_ME_KEY);
  }, []);

  const updateUser = useCallback((updates: Partial<User>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...updates };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  return {
    user,
    rememberMe,
    login,
    logout,
    updateUser,
    isAuthenticated: !!user
  };
};
