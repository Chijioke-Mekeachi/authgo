import { useState, useEffect, useCallback } from 'react';
import { Property } from '../types';

interface PropertyFormData {
  title: string;
  description: string;
  price: number;
  location: string;
  type: string;
  bedrooms: number;
  bathrooms: number;
  amenities: string[];
  images: string[];
}

export const usePropertyManagement = (userId: string) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load properties from localStorage on mount
  useEffect(() => {
    const storedProperties = localStorage.getItem(`properties_${userId}`);
    if (storedProperties) {
      setProperties(JSON.parse(storedProperties));
    }
  }, [userId]);

  // Save properties to localStorage whenever they change
  useEffect(() => {
    if (properties.length > 0) {
      localStorage.setItem(`properties_${userId}`, JSON.stringify(properties));
    }
  }, [properties, userId]);

  const addProperty = useCallback(async (propertyData: PropertyFormData) => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newProperty: Property = {
      id: Date.now(),
      ...propertyData,
      landlordName: 'Current User',
      landlordPhone: '+234 800 000 0000',
      landlordEmail: 'landlord@example.com',
      verified: false,
      rating: 0,
      reviews: 0,
      safetyRating: 4.5,
      isBoostingActive: false,
      views: 0,
      inquiries: 0,
      createdAt: new Date().toISOString()
    };

    setProperties(prev => [newProperty, ...prev]);
    setIsLoading(false);
    
    return newProperty;
  }, []);

  const updateProperty = useCallback(async (id: number, updates: Partial<PropertyFormData>) => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    setProperties(prev =>
      prev.map(prop => (prop.id === id ? { ...prop, ...updates } : prop))
    );
    
    setIsLoading(false);
  }, []);

  const deleteProperty = useCallback(async (id: number) => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    setProperties(prev => prev.filter(prop => prop.id !== id));
    
    setIsLoading(false);
  }, []);

  const incrementViews = useCallback((id: number) => {
    setProperties(prev =>
      prev.map(prop =>
        prop.id === id ? { ...prop, views: (prop.views || 0) + 1 } : prop
      )
    );
  }, []);

  const incrementInquiries = useCallback((id: number) => {
    setProperties(prev =>
      prev.map(prop =>
        prop.id === id ? { ...prop, inquiries: (prop.inquiries || 0) + 1 } : prop
      )
    );
  }, []);

  return {
    properties,
    isLoading,
    addProperty,
    updateProperty,
    deleteProperty,
    incrementViews,
    incrementInquiries
  };
};
