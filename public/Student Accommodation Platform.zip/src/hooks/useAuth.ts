import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { User } from '../types';
import { setAuthTokens, clearAuthTokens } from '../services/api';
import { useLogin as useLoginMutation, useLogout as useLogoutMutation, useSignup as useSignupMutation } from './useApi';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  signup: (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'landlord' | 'agent';
  }) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USER_STORAGE_KEY = 'dormdash_user';
const REMEMBER_ME_KEY = 'dormdash_remember_me';

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const loginMutation = useLoginMutation();
  const logoutMutation = useLogoutMutation();
  const signupMutation = useSignupMutation();

  // Load user from storage on mount
  useEffect(() => {
    const loadUser = () => {
      try {
        const storedUser = localStorage.getItem(USER_STORAGE_KEY);
        const shouldRemember = localStorage.getItem(REMEMBER_ME_KEY) === 'true';
        
        if (storedUser && shouldRemember) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Failed to load user from storage:', error);
        localStorage.removeItem(USER_STORAGE_KEY);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const login = useCallback(async (email: string, password: string, rememberMe: boolean = false) => {
    try {
      const response = await loginMutation.mutateAsync({ email, password });
      
      // Store tokens
      if (response.token && response.refreshToken) {
        setAuthTokens(response.token, response.refreshToken);
      }

      // Store user data
      const userData: User = {
        id: response.user.id || response.user._id,
        name: response.user.name,
        email: response.user.email,
        phone: response.user.phone,
        role: response.user.role,
        verified: response.user.verified || false,
        avatar: response.user.avatar,
        registrationDate: response.user.createdAt || new Date().toISOString(),
      };

      setUser(userData);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userData));
      localStorage.setItem(REMEMBER_ME_KEY, rememberMe.toString());
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }, [loginMutation]);

  const signup = useCallback(async (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'landlord' | 'agent';
  }) => {
    try {
      const response = await signupMutation.mutateAsync(data);
      
      // Store tokens if provided
      if (response.token && response.refreshToken) {
        setAuthTokens(response.token, response.refreshToken);
        
        // Store user data
        const userData: User = {
          id: response.user.id || response.user._id,
          name: response.user.name,
          email: response.user.email,
          phone: response.user.phone,
          role: response.user.role,
          verified: response.user.verified || false,
          avatar: response.user.avatar,
          registrationDate: response.user.createdAt || new Date().toISOString(),
        };

        setUser(userData);
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userData));
        localStorage.setItem(REMEMBER_ME_KEY, 'true');
      }
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    }
  }, [signupMutation]);

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear everything regardless of API response
      setUser(null);
      clearAuthTokens();
    }
  }, [logoutMutation]);

  const updateUser = useCallback((updates: Partial<User>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...updates };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Protected route HOC
export const useRequireAuth = () => {
  const { user, isLoading } = useAuth();
  
  useEffect(() => {
    if (!isLoading && !user) {
      window.location.href = '/';
    }
  }, [user, isLoading]);

  return { user, isLoading };
};

// Role-based access control
export const useRequireRole = (allowedRoles: string[]) => {
  const { user, isLoading } = useAuth();
  
  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        window.location.href = '/';
      } else if (!allowedRoles.includes(user.role)) {
        window.location.href = '/';
      }
    }
  }, [user, isLoading, allowedRoles]);

  return { user, isLoading };
};
