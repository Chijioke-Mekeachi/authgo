/**
 * React Query hooks for API integration
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner@2.0.3';
import api from '../services/api';

// ==================== AUTHENTICATION ====================

export const useLogin = () => {
  return useMutation({
    mutationFn: api.auth.login,
    onSuccess: (data) => {
      toast.success('Login successful!');
    },
    onError: (error: any) => {
      if (error.message?.includes('Backend server is not running')) {
        toast.error('Cannot connect to server', {
          description: 'Please ensure the backend is running on http://localhost:2100',
        });
      } else {
        toast.error(error.message || 'Login failed');
      }
    },
  });
};

export const useSignup = () => {
  return useMutation({
    mutationFn: api.auth.signup,
    onSuccess: () => {
      toast.success('Account created successfully!');
    },
    onError: (error: any) => {
      if (error.message?.includes('Backend server is not running')) {
        toast.error('Cannot connect to server', {
          description: 'Please ensure the backend is running on http://localhost:2100',
        });
      } else {
        toast.error(error.message || 'Signup failed');
      }
    },
  });
};

export const useLogout = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.auth.logout,
    onSuccess: () => {
      queryClient.clear();
      toast.success('Logged out successfully');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Logout failed');
    },
  });
};

// ==================== PROFILE ====================

export const useProfile = () => {
  return useQuery({
    queryKey: ['profile'],
    queryFn: api.profile.getProfile,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 1,
  });
};

export const useCreateProfile = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.profile.createProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      toast.success('Profile created successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to create profile');
    },
  });
};

export const useUpdateProfile = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.profile.updateProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      toast.success('Profile updated successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to update profile');
    },
  });
};

export const useProfileAnalysis = () => {
  return useQuery({
    queryKey: ['profile-analysis'],
    queryFn: api.profile.getAnalysis,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
};

// ==================== PROPERTIES ====================

export const useProperties = () => {
  return useQuery({
    queryKey: ['properties'],
    queryFn: api.product.getAll,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
};

export const useOwnerProperties = (ownerEmail: string) => {
  return useQuery({
    queryKey: ['properties', 'owner', ownerEmail],
    queryFn: () => api.product.getByOwner(ownerEmail),
    enabled: !!ownerEmail,
    staleTime: 2 * 60 * 1000,
  });
};

export const useCreateProperty = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.product.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Property created successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to create property');
    },
  });
};

export const useUploadPropertyImages = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, images }: { productId: string; images: File[] }) =>
      api.product.uploadImages(productId, images),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Images uploaded successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to upload images');
    },
  });
};

export const useUpdateProperty = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) =>
      api.product.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Property updated successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to update property');
    },
  });
};

export const useDeleteProperty = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.product.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Property deleted successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete property');
    },
  });
};

export const useSearchProperties = (params: {
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  type?: string;
  amenities?: string[];
}) => {
  return useQuery({
    queryKey: ['properties', 'search', params],
    queryFn: () => api.product.search(params),
    enabled: Object.values(params).some((v) => v !== undefined && v !== null),
    staleTime: 1 * 60 * 1000, // 1 minute
  });
};

// ==================== INQUIRIES ====================

export const usePropertyInquiries = (propertyId: string) => {
  return useQuery({
    queryKey: ['inquiries', propertyId],
    queryFn: () => api.inquiry.getByProperty(propertyId),
    enabled: !!propertyId,
    staleTime: 1 * 60 * 1000,
  });
};

export const useCreateInquiry = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.inquiry.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inquiries'] });
      toast.success('Inquiry sent successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to send inquiry');
    },
  });
};

// ==================== MESSAGES ====================

export const useUserMessages = (userId: string) => {
  return useQuery({
    queryKey: ['messages', userId],
    queryFn: () => api.message.getUserMessages(userId),
    enabled: !!userId,
    refetchInterval: 30000, // Refetch every 30 seconds
  });
};

export const useSendMessage = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.message.send,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      toast.success('Message sent!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to send message');
    },
  });
};

// ==================== FAVORITES ====================

export const useFavorites = (userId: string) => {
  return useQuery({
    queryKey: ['favorites', userId],
    queryFn: () => api.favorite.getByUser(userId),
    enabled: !!userId,
    staleTime: 5 * 60 * 1000,
  });
};

export const useAddFavorite = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.favorite.add,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorites'] });
      toast.success('Added to favorites!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to add favorite');
    },
  });
};

export const useRemoveFavorite = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.favorite.remove,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorites'] });
      toast.success('Removed from favorites');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to remove favorite');
    },
  });
};

// ==================== PAYMENTS ====================

export const useBoostPlans = () => {
  return useQuery({
    queryKey: ['boost-plans'],
    queryFn: api.payment.getBoostPlans,
    staleTime: 60 * 60 * 1000, // 1 hour
  });
};

export const useInitiatePayment = () => {
  return useMutation({
    mutationFn: api.payment.initiatePayment,
    onSuccess: (data) => {
      // Redirect to Paystack payment page
      if (data.authorization_url) {
        window.location.href = data.authorization_url;
      }
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to initiate payment');
    },
  });
};

export const useVerifyPayment = (reference: string) => {
  return useQuery({
    queryKey: ['payment-verify', reference],
    queryFn: () => api.payment.verifyPayment(reference),
    enabled: !!reference,
    retry: false,
  });
};

// ==================== LANDLORD ====================

export const useLandlordDashboard = () => {
  return useQuery({
    queryKey: ['landlord-dashboard'],
    queryFn: api.landlord.getDashboard,
    staleTime: 5 * 60 * 1000,
  });
};

export const useLandlordListings = () => {
  return useQuery({
    queryKey: ['landlord-listings'],
    queryFn: api.landlord.getListings,
    staleTime: 2 * 60 * 1000,
  });
};

export const useCreateListing = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.landlord.createListing,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landlord-listings'] });
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Listing created successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to create listing');
    },
  });
};

export const useUpdateListingStatus = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.landlord.updateListingStatus,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landlord-listings'] });
      toast.success('Listing status updated!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to update status');
    },
  });
};

// ==================== AGENT ====================

export const useAgentCommissions = (agentId: string) => {
  return useQuery({
    queryKey: ['agent-commissions', agentId],
    queryFn: () => api.agent.getCommissions(agentId),
    enabled: !!agentId,
    staleTime: 5 * 60 * 1000,
  });
};

export const useSettleCommission = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.agent.settleCommission,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agent-commissions'] });
      toast.success('Commission settled successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to settle commission');
    },
  });
};

// ==================== ADMIN ====================

export const useAdminProperties = () => {
  return useQuery({
    queryKey: ['admin-properties'],
    queryFn: api.admin.getProperties,
    staleTime: 2 * 60 * 1000,
  });
};

export const useAdminStats = () => {
  return useQuery({
    queryKey: ['admin-stats'],
    queryFn: api.admin.getStats,
    staleTime: 5 * 60 * 1000,
  });
};

export const useAdminDeleteProperty = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.admin.deleteProperty,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-properties'] });
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      toast.success('Property deleted successfully!');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to delete property');
    },
  });
};
