import { useState, useCallback } from 'react';
import { toast } from 'sonner@2.0.3';

interface UploadedImage {
  url: string;
  file: File;
  preview: string;
}

export const useImageUpload = (maxImages: number = 10, maxSizeMB: number = 5) => {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const compressImage = useCallback(async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Max dimensions
          const maxWidth = 1920;
          const maxHeight = 1080;
          
          if (width > height) {
            if (width > maxWidth) {
              height = (height * maxWidth) / width;
              width = maxWidth;
            }
          } else {
            if (height > maxHeight) {
              width = (width * maxHeight) / height;
              height = maxHeight;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Compress to JPEG with 0.8 quality
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
          resolve(compressedDataUrl);
        };
        
        img.onerror = reject;
      };
      
      reader.onerror = reject;
    });
  }, []);

  const handleImageUpload = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newFiles = Array.from(files);
    
    // Check if adding these would exceed max
    if (images.length + newFiles.length > maxImages) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    setIsUploading(true);

    try {
      const uploadPromises = newFiles.map(async (file) => {
        // Check file size
        const fileSizeMB = file.size / (1024 * 1024);
        if (fileSizeMB > maxSizeMB) {
          toast.error(`${file.name} exceeds ${maxSizeMB}MB limit`);
          return null;
        }

        // Check file type
        if (!file.type.startsWith('image/')) {
          toast.error(`${file.name} is not an image`);
          return null;
        }

        // Compress and create preview
        const compressedUrl = await compressImage(file);
        
        return {
          url: compressedUrl,
          file,
          preview: compressedUrl
        };
      });

      const uploadedImages = (await Promise.all(uploadPromises)).filter(Boolean) as UploadedImage[];
      
      setImages(prev => [...prev, ...uploadedImages]);
      
      if (uploadedImages.length > 0) {
        toast.success(`${uploadedImages.length} image(s) uploaded successfully`);
      }
    } catch (error) {
      toast.error('Failed to upload images');
      console.error('Image upload error:', error);
    } finally {
      setIsUploading(false);
    }
  }, [images.length, maxImages, maxSizeMB, compressImage]);

  const removeImage = useCallback((index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    toast.success('Image removed');
  }, []);

  const clearImages = useCallback(() => {
    setImages([]);
  }, []);

  const getImageUrls = useCallback(() => {
    return images.map(img => img.url);
  }, [images]);

  return {
    images,
    isUploading,
    handleImageUpload,
    removeImage,
    clearImages,
    getImageUrls
  };
};
